# example_usage.py
# Gemini API'yi kullanarak basit bir içerik üretme örneği

import google.generativeai as genai

# API anahtarınızı buraya girin
API_KEY = "YOUR_API_KEY"
genai.configure(api_key=API_KEY)

# Modeli seçelim
model = genai.GenerativeModel("gemini-1.5-flash")

# Basit bir metin üretme örneği
prompt = "Bana Python programlama hakkında 3 kısa bilgi ver."
response = model.generate_content(prompt)

print("📢 Model cevabı:")
print(response.text)
